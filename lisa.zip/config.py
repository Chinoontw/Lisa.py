# config.py

ltuid = "111918821"  # Remplacez par la vraie valeur
ltoken = "v2_CAISDGM5b3FhcTNzM2d1OBokMDdmYjAwOGQtODZhOS00YTExLWI2ODYtOGQyZTEzZjUxNjczINzIhLoGKJT7uKEHMOX9rjVCC2Jic19vdmVyc2Vh.XCRBZwAAAAAB.MEQCIA90lI0p2w38NOSK626vxS4UvpLkYPAE_jMkmJ49ZKybAiB4CknQYaHEjZA3soWvFhpvNB5QLVm0dT_wrp22ypQ0bA"  # Remplacez par la vraie valeur
